/**
 * firebase-config.js
 * ============================================================
 * วิธีใช้: โหลดไฟล์นี้ก่อน cms.js ในทุกหน้า
 *
 * ⚠️  ขั้นตอนตั้งค่า (ทำครั้งเดียว):
 *  1. ไปที่ https://console.firebase.google.com
 *  2. สร้าง Project ใหม่ (ชื่ออะไรก็ได้ เช่น "ob-home-cms")
 *  3. Project Settings → Your apps → Add app → เลือก Web (</>)
 *  4. Copy firebaseConfig แล้วแทนที่ค่าด้านล่างนี้
 *  5. เปิดใช้ใน Firebase Console:
 *     - Authentication → Sign-in method → Email/Password → Enable
 *     - Realtime Database → Create database → Start in test mode (แล้วตั้ง Rules ตามด้านล่าง)
 *     - Storage → Get started → Start in test mode
 *
 * 🔒  Firebase Realtime Database Rules (วางใน Rules tab):
 * {
 *   "rules": {
 *     ".read": true,
 *     ".write": "auth != null"
 *   }
 * }
 *
 * 🔒  Firebase Storage Rules (วางใน Rules tab):
 * rules_version = '2';
 * service firebase.storage {
 *   match /b/{bucket}/o {
 *     match /{allPaths=**} {
 *       allow read: if true;
 *       allow write: if request.auth != null;
 *     }
 *   }
 * }
 * ============================================================
 */

/* ─── แทนที่ค่าข้างล่างด้วยของจริงจาก Firebase Console ─── */
const firebaseConfig = {
  apiKey:            "AIzaSy-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",   // ← เปลี่ยน
  authDomain:        "ob-home-cms.firebaseapp.com",              // ← เปลี่ยน
  databaseURL:       "https://ob-home-cms-default-rtdb.asia-southeast1.firebasedatabase.app", // ← เปลี่ยน
  projectId:         "ob-home-cms",                              // ← เปลี่ยน
  storageBucket:     "ob-home-cms.appspot.com",                  // ← เปลี่ยน
  messagingSenderId: "000000000000",                             // ← เปลี่ยน
  appId:             "1:000000000000:web:xxxxxxxxxxxxxxxxxxxxxxxx" // ← เปลี่ยน
};

/* ─── โหลด Firebase SDK และ init (อย่าแก้ส่วนนี้) ─── */
(function loadFirebase() {
  const SDKs = [
    { src: 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js',     key: 'firebase' },
    { src: 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js',    key: 'auth' },
    { src: 'https://www.gstatic.com/firebasejs/10.12.2/firebase-database-compat.js',key: 'db' },
    { src: 'https://www.gstatic.com/firebasejs/10.12.2/firebase-storage-compat.js', key: 'storage' },
  ];

  let loaded = 0;

  SDKs.forEach(({ src }) => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = () => {
      loaded++;
      if (loaded === SDKs.length) initFirebase();
    };
    document.head.appendChild(s);
  });

  function initFirebase() {
    if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);

    const app = firebase.app();
    const auth    = firebase.auth();
    const db      = firebase.database();
    const storage = firebase.storage();

    /* expose ให้ cms.js ใช้ */
    window._cmsAuth    = auth;
    window._cmsDB      = db;
    window._cmsStorage = storage;

    /* expose modular-style helpers ที่ cms.js ใช้ */
    window._firebaseAuth = {
      onAuthStateChanged: (a, cb) => a.onAuthStateChanged(cb),
      signOut:            (a)     => a.signOut(),
      signInWithEmailAndPassword: (a, email, pw) => a.signInWithEmailAndPassword(email, pw),
    };
    window._firebaseDB = {
      ref:    (db, path) => db.ref(path),
      get:    (ref)      => ref.once('value').then(s => ({ exists: () => s.exists(), val: () => s.val() })),
      set:    (ref, val) => ref.set(val),
      update: (ref, val) => ref.update(val),
    };
    window._firebaseStorage = {
      ref:            (st, path) => st.ref(path),
      uploadBytes:    (ref, file) => ref.put(file).then(snap => ({ ref: snap.ref })),
      getDownloadURL: (ref)      => ref.getDownloadURL(),
    };

    console.log('[OB CMS] Firebase ready ✓');
  }
})();
