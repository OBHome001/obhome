/**
 * OB HOME CMS — cms.js
 * ============================================================
 * วิธีใช้: ใส่ <script src="cms.js"></script> ก่อน </body>
 * ในทุกหน้า HTML ของเว็บ (home, spc, lath, wooden, wallpanel, accessories)
 *
 * ต้องการ: firebase-config.js โหลดก่อน cms.js เสมอ
 * ============================================================
 */

(function () {
  'use strict';

  /* ═══════════════════════════════════════════════════════
     0.  รอ Firebase พร้อม
  ═══════════════════════════════════════════════════════ */
  function waitForFirebase(cb) {
    if (window._cmsDB && window._cmsStorage && window._cmsAuth) {
      cb();
    } else {
      setTimeout(() => waitForFirebase(cb), 80);
    }
  }

  /* ═══════════════════════════════════════════════════════
     1.  ตัวแปรหลัก
  ═══════════════════════════════════════════════════════ */
  let editMode = false;
  let currentUser = null;
  const PAGE = (function () {
    const path = location.pathname.split('/').pop().replace('.html', '') || 'home';
    return path === '' ? 'home' : path;
  })();

  /* ═══════════════════════════════════════════════════════
     2.  UI Bar (ลอยด้านล่าง — เห็นเฉพาะเมื่อ login แล้ว)
  ═══════════════════════════════════════════════════════ */
  function injectBar() {
    const bar = document.createElement('div');
    bar.id = 'cms-bar';
    bar.innerHTML = `
      <div id="cms-bar-inner">
        <span id="cms-bar-logo">✦ OB CMS</span>
        <span id="cms-bar-page">หน้า: <b>${PAGE}</b></span>
        <div id="cms-bar-actions">
          <button id="cms-btn-toggle" class="cms-btn cms-btn-primary">✏️ เปิดแก้ไข</button>
          <button id="cms-btn-save"   class="cms-btn cms-btn-save" style="display:none">💾 บันทึก</button>
          <button id="cms-btn-cancel" class="cms-btn"              style="display:none">✕ ยกเลิก</button>
          <button id="cms-btn-logout" class="cms-btn cms-btn-danger">ออกจากระบบ</button>
        </div>
        <div id="cms-toast"></div>
      </div>
    `;
    document.body.appendChild(bar);

    const style = document.createElement('style');
    style.textContent = `
      #cms-bar {
        position: fixed; bottom: 0; left: 0; right: 0; z-index: 999999;
        background: #1a1a16; color: #faf9f6;
        font-family: 'IBM Plex Sans Thai', 'Opun', sans-serif;
        font-size: 13px; padding: 0 16px;
        box-shadow: 0 -4px 24px rgba(0,0,0,.35);
        border-top: 1px solid rgba(255,255,255,.08);
      }
      #cms-bar-inner {
        max-width: 1200px; margin: 0 auto;
        display: flex; align-items: center; gap: 16px;
        height: 52px; flex-wrap: wrap;
      }
      #cms-bar-logo { font-weight: 700; color: #bca58e; letter-spacing: .06em; }
      #cms-bar-page { color: rgba(255,255,255,.5); font-size: 12px; }
      #cms-bar-page b { color: #fff; }
      #cms-bar-actions { display: flex; gap: 8px; margin-left: auto; align-items: center; }
      .cms-btn {
        padding: 7px 16px; border-radius: 8px; border: 1px solid rgba(255,255,255,.15);
        background: rgba(255,255,255,.08); color: #fff; cursor: pointer;
        font-size: 12px; font-family: inherit; transition: all .2s;
      }
      .cms-btn:hover { background: rgba(255,255,255,.18); }
      .cms-btn-primary { background: #bca58e; border-color: #bca58e; color: #1a1a16; font-weight: 600; }
      .cms-btn-primary:hover { background: #d4c4b0; }
      .cms-btn-save { background: #2c6e3a; border-color: #2c6e3a; font-weight: 600; }
      .cms-btn-save:hover { background: #3a8f4d; }
      .cms-btn-danger { background: rgba(220,50,50,.15); border-color: rgba(220,50,50,.4); color: #f88; }
      .cms-btn-danger:hover { background: rgba(220,50,50,.3); }

      /* edit mode highlight */
      [data-cms-text][contenteditable="true"] {
        outline: 2px dashed #bca58e !important;
        outline-offset: 3px;
        border-radius: 4px;
        cursor: text;
        position: relative;
      }
      [data-cms-text][contenteditable="true"]:focus {
        outline: 2px solid #bca58e !important;
        background: rgba(188,165,142,.07);
      }
      [data-cms-img].cms-img-editable {
        outline: 2px dashed #bca58e;
        outline-offset: 3px;
        cursor: pointer;
        position: relative;
        border-radius: 4px;
      }
      [data-cms-img].cms-img-editable::after {
        content: '📷 เปลี่ยนรูป';
        position: absolute; top: 50%; left: 50%;
        transform: translate(-50%,-50%);
        background: rgba(26,26,22,.8);
        color: #fff; padding: 8px 16px; border-radius: 8px;
        font-size: 13px; font-family: inherit;
        pointer-events: none; white-space: nowrap;
      }
      /* สินค้าใหม่ */
      .cms-add-product-btn {
        display: none; width: 100%; margin-top: 20px;
        padding: 14px; border: 2px dashed #bca58e;
        background: rgba(188,165,142,.06); color: #bca58e;
        border-radius: 10px; cursor: pointer; font-size: 14px;
        font-family: inherit; transition: all .2s;
      }
      .cms-add-product-btn:hover { background: rgba(188,165,142,.14); }
      .cms-delete-card-btn {
        display: none; position: absolute; top: 8px; right: 8px;
        background: #dc3232; color: #fff; border: none;
        width: 28px; height: 28px; border-radius: 50%;
        font-size: 16px; cursor: pointer; z-index: 10;
        align-items: center; justify-content: center;
        line-height: 1;
      }
      body.cms-editing .cms-add-product-btn { display: block; }
      body.cms-editing .cms-delete-card-btn { display: flex; }
      body.cms-editing .product-card { position: relative; }

      /* toast */
      #cms-toast {
        position: fixed; bottom: 62px; right: 20px;
        background: #2c6e3a; color: #fff;
        padding: 10px 20px; border-radius: 10px;
        font-size: 13px; font-family: inherit;
        opacity: 0; transition: opacity .3s; pointer-events: none;
        z-index: 1000000;
      }
      #cms-toast.show { opacity: 1; }

      /* modal รูปภาพ */
      #cms-img-modal {
        display: none; position: fixed; inset: 0; z-index: 1000001;
        background: rgba(0,0,0,.7); align-items: center; justify-content: center;
        backdrop-filter: blur(4px);
      }
      #cms-img-modal.open { display: flex; }
      #cms-img-modal-box {
        background: #1a1a16; border-radius: 16px; padding: 28px 32px;
        width: 90%; max-width: 420px; color: #faf9f6;
        font-family: 'IBM Plex Sans Thai', 'Opun', sans-serif;
      }
      #cms-img-modal h3 { font-size: 16px; margin-bottom: 16px; color: #bca58e; }
      #cms-img-modal input[type=file] {
        width: 100%; padding: 10px; border: 1px dashed rgba(255,255,255,.2);
        border-radius: 8px; color: #fff; background: rgba(255,255,255,.05);
        font-family: inherit; margin-bottom: 8px; cursor: pointer;
      }
      #cms-img-modal-preview {
        width: 100%; max-height: 200px; object-fit: contain;
        border-radius: 8px; margin: 10px 0; display: none;
      }
      #cms-img-modal p { font-size: 12px; color: rgba(255,255,255,.4); margin-bottom: 16px; }
      #cms-img-modal-actions { display: flex; gap: 10px; justify-content: flex-end; }
    `;
    document.head.appendChild(style);

    // image modal
    const modal = document.createElement('div');
    modal.id = 'cms-img-modal';
    modal.innerHTML = `
      <div id="cms-img-modal-box">
        <h3>📷 เปลี่ยนรูปภาพ</h3>
        <input type="file" id="cms-file-input" accept="image/*">
        <img id="cms-img-modal-preview" src="" alt="preview">
        <p>รองรับ JPG, PNG, WEBP — ขนาดแนะนำ ≤ 2MB</p>
        <div id="cms-img-modal-actions">
          <button class="cms-btn" id="cms-img-cancel-btn">ยกเลิก</button>
          <button class="cms-btn cms-btn-save" id="cms-img-confirm-btn">✓ ใช้รูปนี้</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    return bar;
  }

  /* ═══════════════════════════════════════════════════════
     3.  Toast notification
  ═══════════════════════════════════════════════════════ */
  function toast(msg, isError = false) {
    const t = document.getElementById('cms-toast');
    if (!t) return;
    t.textContent = msg;
    t.style.background = isError ? '#8b2020' : '#2c6e3a';
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3000);
  }

  /* ═══════════════════════════════════════════════════════
     4.  Load content จาก Firebase → ใส่ใน DOM
  ═══════════════════════════════════════════════════════ */
  async function loadContent() {
    try {
      const db = window._cmsDB;
      const { ref, get } = window._firebaseDB;
      const snap = await get(ref(db, `pages/${PAGE}`));
      if (!snap.exists()) return;
      const data = snap.val();

      // ── ข้อความ ──
      document.querySelectorAll('[data-cms-text]').forEach(el => {
        const key = el.dataset.cmsText;
        if (data.texts && data.texts[key] !== undefined) {
          el.innerHTML = data.texts[key];
        }
      });

      // ── รูปภาพ ──
      document.querySelectorAll('[data-cms-img]').forEach(el => {
        const key = el.dataset.cmsImg;
        if (data.images && data.images[key]) {
          if (el.tagName === 'IMG') {
            el.src = data.images[key];
          } else {
            // background image (hero section)
            el.style.backgroundImage = `linear-gradient(rgba(0,0,0,.6),rgba(0,0,0,.45)), url('${data.images[key]}')`;
          }
        }
      });

      // ── สินค้า (product cards) ──
      if (data.products) {
        renderProducts(data.products);
      }
    } catch (e) {
      console.warn('CMS load error:', e);
    }
  }

  /* ═══════════════════════════════════════════════════════
     5.  Render product cards (หน้าสินค้า)
  ═══════════════════════════════════════════════════════ */
  function renderProducts(products) {
    const grid = document.querySelector('.product-grid[data-cms-products]');
    if (!grid) return;
    // ล้าง card เดิม (เก็บปุ่ม + เพิ่ม)
    grid.querySelectorAll('.product-card').forEach(c => c.remove());
    products.forEach((p, i) => {
      grid.insertBefore(buildProductCard(p, i), grid.querySelector('.cms-add-product-btn'));
    });
  }

  function buildProductCard(p, idx) {
    const card = document.createElement('div');
    card.className = 'product-card reveal';
    card.dataset.cmsProductIdx = idx;
    card.innerHTML = `
      <button class="cms-delete-card-btn" title="ลบสินค้านี้">✕</button>
      <div class="product-img-box">
        <img src="${p.img || ''}" alt="${p.name || ''}" data-cms-product-img="${idx}">
      </div>
      <div class="product-info">
        <span class="product-code" data-cms-product-field="${idx}:code">${p.code || ''}</span>
        <h3 class="product-name" data-cms-product-field="${idx}:name">${p.name || ''}</h3>
        <div class="product-pattern">
          <div class="pattern-dot" style="background:${p.color || '#ccc'}"></div>
          <span data-cms-product-field="${idx}:pattern">${p.pattern || ''}</span>
        </div>
        <a href="#" class="btn-view">ดูรายละเอียด</a>
      </div>
    `;
    card.querySelector('.cms-delete-card-btn').addEventListener('click', () => deleteProduct(idx));
    return card;
  }

  /* ═══════════════════════════════════════════════════════
     6.  เปิด / ปิด Edit Mode
  ═══════════════════════════════════════════════════════ */
  function enableEditMode() {
    editMode = true;
    document.body.classList.add('cms-editing');
    document.getElementById('cms-btn-toggle').style.display = 'none';
    document.getElementById('cms-btn-save').style.display   = '';
    document.getElementById('cms-btn-cancel').style.display = '';

    // ── text fields ──
    document.querySelectorAll('[data-cms-text]').forEach(el => {
      el.contentEditable = 'true';
    });

    // ── image fields ──
    document.querySelectorAll('[data-cms-img]').forEach(el => {
      el.classList.add('cms-img-editable');
      el.addEventListener('click', onImgClick);
    });

    // ── product image + field (dynamic) ──
    bindProductEditors();
  }

  function disableEditMode() {
    editMode = false;
    document.body.classList.remove('cms-editing');
    document.getElementById('cms-btn-toggle').style.display = '';
    document.getElementById('cms-btn-save').style.display   = 'none';
    document.getElementById('cms-btn-cancel').style.display = 'none';

    document.querySelectorAll('[data-cms-text]').forEach(el => {
      el.contentEditable = 'false';
    });
    document.querySelectorAll('[data-cms-img]').forEach(el => {
      el.classList.remove('cms-img-editable');
      el.removeEventListener('click', onImgClick);
    });
  }

  function bindProductEditors() {
    // text fields ภายใน product cards
    document.querySelectorAll('[data-cms-product-field]').forEach(el => {
      el.contentEditable = 'true';
      el.style.outline = '1px dashed #bca58e';
      el.style.borderRadius = '3px';
    });
    // รูปสินค้า
    document.querySelectorAll('[data-cms-product-img]').forEach(img => {
      img.style.cursor = 'pointer';
      img.style.outline = '2px dashed #bca58e';
      img.addEventListener('click', onProductImgClick);
    });
  }

  /* ═══════════════════════════════════════════════════════
     7.  Image modal logic
  ═══════════════════════════════════════════════════════ */
  let _currentImgTarget = null; // el ที่จะเปลี่ยนรูป
  let _currentImgFile   = null;

  function onImgClick(e) {
    if (!editMode) return;
    e.preventDefault(); e.stopPropagation();
    _currentImgTarget = e.currentTarget;
    openImgModal();
  }

  function onProductImgClick(e) {
    if (!editMode) return;
    e.preventDefault(); e.stopPropagation();
    _currentImgTarget = e.currentTarget;
    openImgModal();
  }

  function openImgModal() {
    _currentImgFile = null;
    document.getElementById('cms-file-input').value = '';
    document.getElementById('cms-img-modal-preview').style.display = 'none';
    document.getElementById('cms-img-modal').classList.add('open');
  }

  function closeImgModal() {
    document.getElementById('cms-img-modal').classList.remove('open');
    _currentImgTarget = null;
    _currentImgFile   = null;
  }

  /* ═══════════════════════════════════════════════════════
     8.  บันทึก (Save) ข้อมูลทั้งหมด
  ═══════════════════════════════════════════════════════ */
  async function saveAll() {
    const saveBtn = document.getElementById('cms-btn-save');
    saveBtn.textContent = '⏳ กำลังบันทึก...';
    saveBtn.disabled = true;

    try {
      const db      = window._cmsDB;
      const storage = window._cmsStorage;
      const { ref: dbRef, set, update } = window._firebaseDB;
      const { ref: stRef, uploadBytes, getDownloadURL } = window._firebaseStorage;

      const texts  = {};
      const images = {};
      const products = [];

      // ── รวบรวม texts ──
      document.querySelectorAll('[data-cms-text]').forEach(el => {
        texts[el.dataset.cmsText] = el.innerHTML;
      });

      // ── รวบรวม images (อาจมี pending upload) ──
      // pending uploads เก็บใน element dataset
      const uploadJobs = [];
      document.querySelectorAll('[data-cms-img]').forEach(el => {
        const key  = el.dataset.cmsImg;
        const file = el._pendingFile;
        if (file) {
          const storRef = stRef(storage, `pages/${PAGE}/${key}_${Date.now()}`);
          uploadJobs.push(
            uploadBytes(storRef, file).then(snap => getDownloadURL(snap.ref)).then(url => {
              images[key] = url;
              if (el.tagName === 'IMG') el.src = url;
              else el.style.backgroundImage = `linear-gradient(rgba(0,0,0,.6),rgba(0,0,0,.45)), url('${url}')`;
              delete el._pendingFile;
            })
          );
        } else {
          // เก็บ url เดิม
          if (el.tagName === 'IMG') images[key] = el.src;
          else {
            const m = (el.style.backgroundImage || '').match(/url\(['"]?(.+?)['"]?\)\s*$/);
            if (m) images[key] = m[1];
          }
        }
      });

      // ── รวบรวม products ──
      const grid = document.querySelector('.product-grid[data-cms-products]');
      if (grid) {
        const cards = grid.querySelectorAll('.product-card');
        const productUploadJobs = [];

        cards.forEach((card, idx) => {
          const p = {
            code:    (card.querySelector('[data-cms-product-field$=":code"]')  || {}).innerText || '',
            name:    (card.querySelector('[data-cms-product-field$=":name"]')  || {}).innerText || '',
            pattern: (card.querySelector('[data-cms-product-field$=":pattern"]') || {}).innerText || '',
            color:   (card.querySelector('.pattern-dot') || {}).style?.background || '#ccc',
            img:     (card.querySelector('img') || {}).src || '',
          };
          const imgEl = card.querySelector('[data-cms-product-img]');
          if (imgEl && imgEl._pendingFile) {
            const file = imgEl._pendingFile;
            const storRef = stRef(storage, `pages/${PAGE}/product_${idx}_${Date.now()}`);
            productUploadJobs.push(
              uploadBytes(storRef, file).then(s => getDownloadURL(s.ref)).then(url => {
                p.img = url;
                imgEl.src = url;
                delete imgEl._pendingFile;
              })
            );
          }
          products.push(p);
        });

        await Promise.all(productUploadJobs);
      }

      await Promise.all(uploadJobs);

      // ── เขียน Firebase ──
      const payload = { texts };
      if (Object.keys(images).length) payload.images = images;
      if (products.length) payload.products = products;
      await set(dbRef(db, `pages/${PAGE}`), payload);

      toast('✓ บันทึกสำเร็จ!');
    } catch (err) {
      console.error(err);
      toast('เกิดข้อผิดพลาด: ' + err.message, true);
    } finally {
      saveBtn.textContent = '💾 บันทึก';
      saveBtn.disabled = false;
    }
  }

  /* ═══════════════════════════════════════════════════════
     9.  เพิ่ม / ลบ สินค้า
  ═══════════════════════════════════════════════════════ */
  function addProduct() {
    const grid = document.querySelector('.product-grid[data-cms-products]');
    if (!grid) return;
    const cards = grid.querySelectorAll('.product-card');
    const idx   = cards.length;
    const newP  = { code: `ID: NEW-${String(idx+1).padStart(3,'0')}`, name: 'ชื่อสินค้าใหม่', pattern: 'ลาย: -', color: '#bca58e', img: '' };
    const card  = buildProductCard(newP, idx);
    grid.insertBefore(card, grid.querySelector('.cms-add-product-btn'));
    if (editMode) {
      card.querySelector('[data-cms-product-field]') && bindProductEditors();
      const delBtn = card.querySelector('.cms-delete-card-btn');
      if (delBtn) delBtn.style.display = 'flex';
    }
    toast('เพิ่มสินค้าแล้ว — กรอกข้อมูลแล้วกดบันทึก');
  }

  function deleteProduct(idx) {
    if (!confirm('ลบสินค้านี้?')) return;
    const grid = document.querySelector('.product-grid[data-cms-products]');
    if (!grid) return;
    const card = grid.querySelector(`[data-cms-product-idx="${idx}"]`);
    if (card) card.remove();
    // reindex
    grid.querySelectorAll('.product-card').forEach((c, i) => {
      c.dataset.cmsProductIdx = i;
    });
    toast('ลบสินค้าแล้ว — กดบันทึกเพื่อยืนยัน');
  }

  /* ═══════════════════════════════════════════════════════
     10.  Auth — ตรวจว่า login อยู่ไหม
  ═══════════════════════════════════════════════════════ */
  function initAuth() {
    const auth = window._cmsAuth;
    const { onAuthStateChanged, signOut } = window._firebaseAuth;

    onAuthStateChanged(auth, user => {
      currentUser = user;
      const bar = document.getElementById('cms-bar');
      if (!bar) return;

      if (user) {
        bar.style.display = '';
        loadContent();
      } else {
        bar.style.display = 'none';
        // ยัง load content เพื่อผู้เยี่ยมชมทั่วไปเห็น
        loadContent();
      }
    });

    document.getElementById('cms-btn-logout').addEventListener('click', () => {
      signOut(auth).then(() => { disableEditMode(); toast('ออกจากระบบแล้ว'); });
    });
  }

  /* ═══════════════════════════════════════════════════════
     11.  เชื่อม Events ทั้งหมด
  ═══════════════════════════════════════════════════════ */
  function bindEvents() {
    document.getElementById('cms-btn-toggle').addEventListener('click', () => {
      if (!currentUser) { alert('กรุณา login ก่อน'); return; }
      enableEditMode();
    });

    document.getElementById('cms-btn-save').addEventListener('click', saveAll);

    document.getElementById('cms-btn-cancel').addEventListener('click', () => {
      disableEditMode();
      loadContent(); // reload ค่าเดิมจาก Firebase
    });

    // ── image modal ──
    document.getElementById('cms-file-input').addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file) return;
      _currentImgFile = file;
      const preview = document.getElementById('cms-img-modal-preview');
      preview.src = URL.createObjectURL(file);
      preview.style.display = 'block';
    });

    document.getElementById('cms-img-confirm-btn').addEventListener('click', () => {
      if (!_currentImgFile || !_currentImgTarget) { closeImgModal(); return; }
      const url = URL.createObjectURL(_currentImgFile);
      const el  = _currentImgTarget;
      el._pendingFile = _currentImgFile;
      if (el.tagName === 'IMG') {
        el.src = url;
      } else {
        el.style.backgroundImage = `linear-gradient(rgba(0,0,0,.6),rgba(0,0,0,.45)), url('${url}')`;
      }
      closeImgModal();
      toast('เลือกรูปแล้ว — กดบันทึกเพื่ออัปโหลด');
    });

    document.getElementById('cms-img-cancel-btn').addEventListener('click', closeImgModal);
    document.getElementById('cms-img-modal').addEventListener('click', e => {
      if (e.target === document.getElementById('cms-img-modal')) closeImgModal();
    });

    // ── ปุ่มเพิ่มสินค้า ──
    document.querySelectorAll('.cms-add-product-btn').forEach(btn => {
      btn.addEventListener('click', addProduct);
    });
  }

  /* ═══════════════════════════════════════════════════════
     12.  Bootstrap
  ═══════════════════════════════════════════════════════ */
  function init() {
    injectBar();
    bindEvents();
    initAuth();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => waitForFirebase(init));
  } else {
    waitForFirebase(init);
  }

})();
